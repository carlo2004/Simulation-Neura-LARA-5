robot.move_to([0.45, -0.12, 0.26])
