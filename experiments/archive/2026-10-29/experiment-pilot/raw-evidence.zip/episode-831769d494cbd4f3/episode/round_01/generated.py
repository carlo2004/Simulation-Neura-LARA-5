import time
# Staple the red cube onto the blue cube
# 1. Grasp the blue cube first
robot.gripper(closed=True)
print(f"Blue cube at: {robot.position("blue")}")

# 2. Move to position above the red cube (to place it on top)
# Red cube centre is [0.4, -0.12, 0.019957], so we need to move there
red_pos = [0.4, -0.12, 0.019957]
tcp_to_red = robot.move_to(red_pos)
print(f"Moved TCP to red cube position: {tcp_to_red}")

# 3. Open gripper to release blue cube from its original position (if needed)
# Actually we need the blue cube in hand first, then move it onto red
# Let me reconsider: we should grasp blue, then move to red and place it

# Alternative approach - more standard:
# 1. Grasp blue cube
robot.gripper(closed=True)
print(f"Blue cube grabbed at: {robot.position("blue")}")

# 2. Move TCP to be above the red cube (to place it on top)
red_pos = [0.4, -0.12, 0.019957]
tcp_to_red = robot.move_to(red_pos)
print(f"Moved TCP to red cube position: {tcp_to_red}")

# 3. Open gripper (to release blue from its original spot if needed)
# Actually we need the blue cube in hand, so we should move it onto red
# But first let me check - do we need to open the gripper on blue?
# The standard
