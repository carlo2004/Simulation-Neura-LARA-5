# Pick up red cube
robot.gripper(closed=True)
robot.move_to([0.4, -0.12, 0.04])  # lift slightly above table
# Place red on blue
robot.gripper(closed=True)
robot.move_to([0.4, 0.12, 0.08])  # center above blue top
robot.gripper(closed=False)
