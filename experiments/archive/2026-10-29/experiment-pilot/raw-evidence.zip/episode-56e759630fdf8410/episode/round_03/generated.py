robot.gripper(closed=False)
# move to red cube centre (under red)
robot.move_to([0.4, -0.12, 0.019957 + 0.02])  # top clearance ~0.04
robot.gripper(closed=True)
# now move to blue top centre while holding red
robot.move_to([0.4, 0.12, 0.019957 + 0.02])  # directly above blue top
robot.gripper(closed=False)  # open to drop red on blue
