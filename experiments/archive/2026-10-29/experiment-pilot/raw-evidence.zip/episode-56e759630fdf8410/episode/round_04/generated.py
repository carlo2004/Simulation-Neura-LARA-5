robot.gripper(closed=False)
# read current positions
r = robot.position("red")
b = robot.position("blue")
# place TCP just above red centre (to pick red)
z_pick = r[2] + r[2]  # cube half height = 0.02, so centre + 0.02
robot.move_to([r[0], r[1], z_pick])
robot.gripper(closed=True)
# now TCP is at blue top centre
z_blue_top = b[2] + b[2]
robot.move_to([b[0], b[1], z_blue_top])
# grip closed already true; keep holding red while moving over blue
# open gripper directly above blue to drop red onto blue
robot.gripper(closed=False)
# optionally move TCP slightly forward/backward in x to center over blue? but centre is b[0],b[1]
# just open at blue top
