robot.gripper(closed=True)
