robot.gripper(closed=False)
robot.move_to([0.4, -0.12, 0.04])  # just above red top
robot.gripper(closed=True)
robot.move_to([0.4, 0.12, 0.08])  # above blue top (center)
robot.gripper(closed=False)
