robot.move_to([0.55, -0.12, 0.26])
