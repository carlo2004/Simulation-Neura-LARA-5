robot.move_to([0.6, -0.12, 0.26])
