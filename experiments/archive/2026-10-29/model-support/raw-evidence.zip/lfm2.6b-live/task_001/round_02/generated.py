robot.move_to([0.5, -0.12, 0.26])
